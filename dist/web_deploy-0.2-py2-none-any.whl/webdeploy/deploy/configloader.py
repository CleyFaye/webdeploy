# encoding=utf-8
"""
Read project configuration
"""
if __name__ == '__main__':
    raise Exception('This program cannot be run in DOS mode.')

import sys
from os import (
        environ,
        )

def config():
    """Return the project configuration.

    The project configuration is a python file named config.py containing 
    specific variables. We look in two places for this file:
    - If an environment variable named DEPLOY_CONFIG exist, it is used as a
      path containing the config.py file
    - Otherwise, the current directory is used.
    """
    myself = config
    try:
        return myself.cache
    except AttributeError:
        pass
    sys.dont_write_bytecode = True
    if 'DEPLOY_CONFIG' in environ:
        sys.path.append(environ['DEPLOY_CONFIG'])
    import config as projectConfig
    sys.dont_write_bytecode = False
    if 'DEPLOY_CONFIG' in environ:
        sys.path.remove(environ['DEPLOY_CONFIG'])
    myself.cache = projectConfig
    return projectConfig

